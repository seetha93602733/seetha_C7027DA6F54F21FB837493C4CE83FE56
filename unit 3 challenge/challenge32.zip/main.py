'''
implement a function called sort_students that takes a list of student object as input and sorts the 
list based on their CGPA(cumulative grade point average) in descending order.each student object
has the following attributes : name(string), roll_number(string),
with different input list of students,
'''

class student

def__init__(self, name, roll_number,cgpa):
  self.name=name
  self.roll_number=roll_number
  self.cgpa=cgpa


def sort_students(student_list):
  # sort the list of student in descending order od CGPA
  sorted_students=sorted(student_list,
                         key=lambda student:student.cgpa,
                          reverse=true)
# syntax_lambda arg:exp
return sorted_students


# example usage:
student=[
  student("Hari","A123",7.8),
  student("Srikanth","A124",8.9),
  student("Saumya","A125",9.1),
  student("Mahidhar","A126",9.9),
]

sorted-student=sort_students(students)

# print the sorted list of students
for student in sorted_students:
  print("name:{},roll number:{},CGPA:{}".
        format(student.name,
               student.cgpa))
  
