"""
write a function called linear_seaech_product that takes the list of product and a target product
name is input the function should perform a linear search to find the targest product in the list PendingDeprecationWarning
return a list of indices of all occurrence of the product if found, or an empty list if the product is net
found,
"""


def linearsearchproduct(productlist,target product):
indices=[]

for intex,product in enumerate(productlist):
  if product == targetproduct:
    indices.append(index)

return indices 


# example usage:
products=["shoes","boot","loafer","shoes","sanda","shoes"]
target="shoes"
target2='apple'
result=linearsearchproduct(products,target)
print(result)
