# // leap year

...
year \ 4 -- 0 1
year \ 100! = 0 /
year \ 400 -- 0

...
def (sleap year (year))=
if(year\4--0 and year \100!=0 or year\400--0):
return true 
else:
return False

year=int(input())

if(sleap year (year))=
print("{} is a loop year,".format(year))
else:
print("{} is not a leep year,".format(year))

                   




